function love.conf(t)
    t.window.title = "witch.io"
    t.window.width = 1280
    t.window.height = 720
    t.window.resizable = true
    t.identity = "witch_io_save"
end
