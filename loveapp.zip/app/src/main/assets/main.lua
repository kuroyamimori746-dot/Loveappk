DEATH_RETURN_DELAY = 1.6 -- seconds (not used for auto-return, just for visuals)

deathTimer = deathTimer or 0


function logState(msg)
    if type(msg) == 'string' then print('[STATE] '..msg) end
end

-- Global game constants (safe defaults)
DEATH_RETURN_DELAY = 3 -- seconds to return to menu after death
deathTimer = 0
gameState = gameState or 'Menu'

-- FILE: main.lua
-- witch.io — Love2D FFA prototype (polished, sprites + UI + self-test)
-- Drop the two files (conf.lua + main.lua) into a folder, add an `assets/` folder
-- with optional images: witch_player.png, witch_bot.png, bullet.png, bg_tile.png,
-- ui_fire.png, ui_dash.png
-- If assets are missing the code will gracefully fall back to shapes.

local lg = love.graphics
local lm = love.math
local fs = love.filesystem

math.randomseed(os.time())

-- World
local WORLD = { w = 3000, h = 3000 }
local camera = { x = 0, y = 0, lerp = 8 }

-- Game state
local entities = {}
local bullets = {}
local particles = {}
local player = nil
local state = "menu" -- menu, playing, upgrade, dead, settings
local timeElapsed = 0
local highscore = 0
local deathTimer = 0

-- Tunables
local PLAYER_SPEED = 220
local BULLET_SPEED = 700
local FIRE_RATE = 0.22
local DASH_SPEED = 520
local DASH_TIME = 0.18
local BOT_COUNT = 8
local LEVEL_XP_BASE = 100
local UPGRADE_CAP = 5
local RESPAWN_DELAY = 2.0
local RESPAWN_SAFE_DIST = 250
local RESPAWN_INVUL = 2.0 -- seconds of invulnerability
local XP_PER_KILL = 30
local FIRERATE_PER_LEVEL = 0.06
local AIM_NOISE = 0.12
local DODGE_CHANCE = 0.20

-- Joystick settings
local joystickSettings = { x = 140, y = 560, size = 120 }
local SETTINGS_FILE = "witchio_settings.cfg"
local HIGHSCORE_FILE = "witchio_highscore.dat"


local function saveSettings()
    -- Save joystick settings in CSV format matching loadSettings
    local ok, err = pcall(function()
        fs.write(SETTINGS_FILE, string.format("%d,%d,%d", joystickSettings.x or 0, joystickSettings.y or 0, joystickSettings.size or 120))
        fs.write(HIGHSCORE_FILE, tostring(highscore or 0))
    end)
    if not ok then
        print("[saveSettings] failed to write settings:", err)
    end
end

-- Sounds (stubs if missing)
local sounds = {}

-- Graphics assets (nil if missing)
local gfx = { player = nil, bot = nil, bullet = nil, bg = nil, ui_fire = nil, ui_dash = nil }

-- Telemetry / debug
local telemetry = { enabled = false, runs = {}, current = nil }
local DEBUG_SELFTEST = true -- set true to auto-run self-tests when the game starts

-- UI: touch buttons and kill feed
local ui = {
    shootButton = { x = 0, y = 0, r = 48, pressed = false, desktopClick = false },
    dashButton  = { x = 0, y = 0, r = 36, pressed = false, desktopClick = false },
    killFeed = {}, -- list of {text, timer}
    killFeedMax = 6,
    killFeedTime = 4.0,
}

-- Fonts
local uiFont = nil
local titleFont = nil

-- Utility
local function clamp(v,a,b) return math.max(a, math.min(b, v)) end
local function dist(ax,ay,bx,by) return math.sqrt((ax-bx)^2 + (ay-by)^2) end

-- Safe tonumber: trims input and only converts clean numeric strings
local function safe_tonumber(s)
    if not s then return nil end
    if type(s) ~= "string" then s = tostring(s) end
    -- trim whitespace
    local t = s:match("^%s*(.-)%s*$")
    if t == "" or t == nil then return nil end
    -- try direct tonumber first (supports floats)
    local n = tonumber(t)
    if n ~= nil then return n end
    -- fallback: try to extract leading integer portion
    local i = t:match("^([+-]?%d+)")
    if i then return tonumber(i) end
    return nil
end



-- Persistence
local function loadSettings()
    if fs.getInfo(SETTINGS_FILE) then
        local data = fs.read(SETTINGS_FILE)
        if data then
            local x,y,s = data:match("([^,]+),([^,]+),([^,]+)")
            if x then joystickSettings.x = safe_tonumber(x) or joystickSettings.x end
            if y then joystickSettings.y = safe_tonumber(y) or joystickSettings.y end
            if s then joystickSettings.size = safe_tonumber(s) or joystickSettings.size end
        end
    end
    if fs.getInfo(HIGHSCORE_FILE) then
        local raw = fs.read(HIGHSCORE_FILE)
        if raw then
            local hs = safe_tonumber(raw)
            if hs then highscore = hs end
        end
    end
end



-- Sounds
local function loadSounds()
    local function safeLoad(name)
        if fs.getInfo("assets/"..name) then
            return love.audio.newSource("assets/"..name, "static")
        end
        -- return a no-op stub
        return { play = function() end }
    end
    sounds.shoot = safeLoad("shoot.wav")
    sounds.hit = safeLoad("hit.wav")
    sounds.levelup = safeLoad("levelup.wav")
    sounds.death = safeLoad("death.wav")
    sounds.ui = safeLoad("ui.wav")
end

-- Graphics
local function loadGraphics()
    local function safeImage(name)
        if fs.getInfo("assets/"..name) then
            return lg.newImage("assets/"..name)
        end
        return nil
    end
    gfx.player = safeImage("witch_player.png")
    gfx.bot = safeImage("witch_bot.png")
    gfx.bullet = safeImage("bullet.png")
    gfx.bg = safeImage("bg_tile.png")
    gfx.ui_fire = safeImage("ui_fire.png")
    gfx.ui_dash = safeImage("ui_dash.png")
end

-- Kill feed helper
local function pushKillFeed(text)
    table.insert(ui.killFeed, 1, { text = text, timer = ui.killFeedTime })
    if #ui.killFeed > ui.killFeedMax then table.remove(ui.killFeed) end
end

-- Entity factory
local function makeEntity(isHuman)
    local baseHP = 5
    local e = {
        id = lm.random(),
        name = isHuman and "You" or ("Bot"..tostring(math.floor(lm.random()*9000)+1000)),
        x = lm.random(100, WORLD.w-100),
        y = lm.random(100, WORLD.h-100),
        r = 18,
        angle = 0,
        cooldown = 0,
        hp = baseHP,
        maxhp = baseHP,
        isDashing = false,
        dashTimer = 0,
        score = 0,
        xp = 0,
        level = 1,
        upgrades = { fireRate = 0, bulletSpeed = 0, maxHP = 0, dashReduction = 0 },
        pendingUpgrade = nil,
        dead = false,
        respawnTimer = 0,
        invulTimer = 0,
        isHuman = isHuman,
    }
    return e
end

local function initGame(botCount)
    bullets = {}
    particles = {}
    entities = {}
    player = makeEntity(true)
    table.insert(entities, player)
    botCount = botCount or BOT_COUNT
    for i=1,botCount do table.insert(entities, makeEntity(false)) end
    timeElapsed = 0
    if telemetry.enabled then
        telemetry.current = { events = {}, perEntity = {}, start = os.time() }
        for _,e in ipairs(entities) do telemetry.current.perEntity[e.name] = { kills = 0, deaths = 0, respawns = 0 } end
    end
end

-- Camera
local function updateCamera(dt)
    if not player then return end
    local targetX = player.x - lg.getWidth()/2
    local targetY = player.y - lg.getHeight()/2
    camera.x = camera.x + (targetX - camera.x) * clamp(camera.lerp * dt, 0, 1)
    camera.y = camera.y + (targetY - camera.y) * clamp(camera.lerp * dt, 0, 1)
    camera.x = clamp(camera.x, 0, math.max(0, WORLD.w - lg.getWidth()))
    camera.y = clamp(camera.y, 0, math.max(0, WORLD.h - lg.getHeight()))
end

-- Shooting
local function shootBullet(e)
    if not e or e.dead or e.invulTimer > 0 then return end
    if e.cooldown > 0 then return end
    local speed = BULLET_SPEED * (1 + 0.1 * e.upgrades.bulletSpeed)
    local bx = e.x + math.cos(e.angle) * (e.r + 6)
    local by = e.y + math.sin(e.angle) * (e.r + 6)
    local b = { owner = e, x = bx, y = by, angle = e.angle, speed = speed, r = 6, life = 2.6 }
    table.insert(bullets, b)
    e.cooldown = FIRE_RATE * math.max(0.3, 1 - FIRERATE_PER_LEVEL * e.upgrades.fireRate)
    if sounds.shoot and sounds.shoot.play then sounds.shoot:play() end
end

local function spawnHitParticles(x,y)
    for i=1,6 do
        local a = lm.random() * (2 * math.pi)
        local s = lm.random(40,160)
        table.insert(particles, { x=x, y=y, vx=math.cos(a)*s, vy=math.sin(a)*s, life=lm.random()*0.6+0.2 })
    end
end

-- XP/level
local function giveXP(e, amount)
    if not e then return end
    e.xp = e.xp + amount
    local need = LEVEL_XP_BASE
    while e.xp >= need do
        e.xp = e.xp - need
        e.level = e.level + 1
        local choices = {"fireRate","bulletSpeed","maxHP","dashReduction"}
        local a = choices[math.random(1,#choices)]
        local b = choices[math.random(1,#choices)]
        while b == a do b = choices[math.random(1,#choices)] end
        if e.isHuman then
            -- pause for player choice
            e.pendingUpgrade = {a,b}
            state = 'upgrade'
            return
        else
            local pick = a
            if e.upgrades.maxHP < 2 and lm.random() < 0.6 then pick = 'maxHP' end
            e.upgrades[pick] = clamp(e.upgrades[pick] + 1, 0, UPGRADE_CAP)
            if pick == 'maxHP' then e.maxhp = e.maxhp + 1; e.hp = e.hp + 1 end
        end
    end
end

-- Safe respawn
local function findSafeRespawn()
    for attempt = 1, 40 do
        local rx = lm.random(100, WORLD.w-100)
        local ry = lm.random(100, WORLD.h-100)
        local ok = true
        for _,o in ipairs(entities) do
            if not o.dead and dist(rx,ry,o.x,o.y) < RESPAWN_SAFE_DIST then ok = false; break end
        end
        if ok then return rx, ry end
    end
    return lm.random(100, WORLD.w-100), lm.random(100, WORLD.h-100)
end

-- Bot AI: aim noise and dodge
local function updateBot(e, dt)
    if e.dead then return end
    local target, bestd = nil, 1e9
    for _,o in ipairs(entities) do
        if o ~= e and not o.dead then
            local d = dist(e.x,e.y,o.x,o.y)
            if d < bestd then bestd, target = d, o end
        end
    end
    if target then
        local baseAng = math.atan2(target.y - e.y, target.x - e.x)
        e.angle = baseAng + (lm.random() * 2 - 1) * AIM_NOISE
        local d = dist(e.x,e.y,target.x,target.y)
        for _,b in ipairs(bullets) do
            if b.owner ~= e and not b.owner.dead then
                local db = dist(b.x,b.y,e.x,e.y)
                if db < 180 then
                    local relang = math.abs(math.atan2(e.y - b.y, e.x - b.x) - b.angle)
                    if relang < 0.6 and lm.random() < DODGE_CHANCE then
                        local perp = math.pi/2 * (lm.random() < 0.5 and 1 or -1)
                        e.x = clamp(e.x + math.cos(b.angle + perp) * PLAYER_SPEED * dt, 20, WORLD.w-20)
                        e.y = clamp(e.y + math.sin(b.angle + perp) * PLAYER_SPEED * dt, 20, WORLD.h-20)
                    end
                end
            end
        end
        if d > 140 then
            local vx = math.cos(e.angle) * (PLAYER_SPEED * 0.8) * dt
            local vy = math.sin(e.angle) * (PLAYER_SPEED * 0.8) * dt
            e.x = clamp(e.x + vx, 20, WORLD.w-20)
            e.y = clamp(e.y + vy, 20, WORLD.h-20)
        else
            if e.cooldown <= 0 then shootBullet(e) end
        end
    end
    e.cooldown = math.max(0, e.cooldown - dt)
end

-- Bullet update and collisions
local function updateBullets(dt)
    for i = #bullets, 1, -1 do
        local b = bullets[i]
        b.x = b.x + math.cos(b.angle) * b.speed * dt
        b.y = b.y + math.sin(b.angle) * b.speed * dt
        b.life = b.life - dt
        if b.life <= 0 then
            table.remove(bullets, i)
            goto continue
        end
        for j = #entities, 1, -1 do
            local e = entities[j]
            if not e.dead and e.invulTimer <= 0 and b.owner ~= e and (b.x - e.x)^2 + (b.y - e.y)^2 <= (b.r + e.r)^2 then
                e.hp = e.hp - 1
                spawnHitParticles(b.x, b.y)
                if sounds.hit and sounds.hit.play then sounds.hit:play() end
                if b.owner and not b.owner.dead then giveXP(b.owner, XP_PER_KILL/1) end
                if e.hp <= 0 then
                    e.dead = true
                    e.respawnTimer = RESPAWN_DELAY
                    if telemetry.enabled and telemetry.current and telemetry.current.perEntity and telemetry.current.perEntity[e.name] then
                        telemetry.current.perEntity[e.name].deaths = telemetry.current.perEntity[e.name].deaths + 1
                    end
                    if b.owner and b.owner ~= e then
                        b.owner.score = b.owner.score + 1
                        pushKillFeed(b.owner.name .. " → " .. e.name)
                        if telemetry.enabled and telemetry.current and telemetry.current.perEntity[b.owner.name] then
                            telemetry.current.perEntity[b.owner.name].kills = telemetry.current.perEntity[b.owner.name].kills + 1
                        end
                    end
                    if e.isHuman then
                        state = 'dead'
                        deathTimer = 0
                        highscore = math.max(highscore, player.score)
                        saveSettings()
                    end
                end
                table.remove(bullets, i)
                break
            end
        end
        ::continue::
    end
end

-- Drawers
local function drawBackground()
    if gfx.bg then
        -- tiled background
        local bw = gfx.bg:getWidth()
        local bh = gfx.bg:getHeight()
        for x=0, WORLD.w-1, bw do
            for y=0, WORLD.h-1, bh do
                lg.draw(gfx.bg, x, y)
            end
        end
    else
        lg.setColor(0.07,0.07,0.12); lg.rectangle('fill', 0, 0, WORLD.w, WORLD.h)
        lg.setColor(0.09,0.09,0.14)
        for gx=0, WORLD.w, 200 do lg.line(gx,0,gx,WORLD.h) end
        for gy=0, WORLD.h, 200 do lg.line(0,gy,WORLD.w,gy) end
    end
end

local function drawWorld()
    drawBackground()

    for _,e in ipairs(entities) do
        if e.dead then lg.setColor(0.3,0.3,0.3,0.6)
        elseif e.invulTimer>0 then lg.setColor(0.4,0.8,1,0.9)
        else lg.setColor(1,1,1) end
        if e.isHuman and gfx.player then
            lg.draw(gfx.player, e.x, e.y, e.angle, 1, 1, gfx.player:getWidth()/2, gfx.player:getHeight()/2)
        elseif (not e.isHuman) and gfx.bot then
            lg.draw(gfx.bot, e.x, e.y, e.angle, 1, 1, gfx.bot:getWidth()/2, gfx.bot:getHeight()/2)
        else
            -- fallback circle
            if e.dead then lg.setColor(0.3,0.3,0.3,0.6)
            elseif e.invulTimer>0 then lg.setColor(0.4,0.8,1,0.9)
            else lg.setColor(e.isHuman and 0.05 or 0.7, e.isHuman and 0.6 or 0.3, e.isHuman and 0.6 or 0.9) end
            lg.circle('fill', e.x, e.y, e.r)
        end
        if e.invulTimer and e.invulTimer > 0 then lg.setColor(1,1,1,0.12); lg.circle('fill', e.x, e.y, e.r+10) end
        lg.setColor(1,1,1); lg.print(e.name, e.x - 10, e.y - e.r - 12)
    end

    for _,b in ipairs(bullets) do
        if gfx.bullet then
            lg.draw(gfx.bullet, b.x, b.y, 0, 1, 1, gfx.bullet:getWidth()/2, gfx.bullet:getHeight()/2)
        else
            lg.setColor(1,0.85,0.35); lg.circle('fill', b.x, b.y, b.r)
        end
    end
    for _,p in ipairs(particles) do lg.setColor(1,0.6,0.8, math.max(0,p.life)); lg.circle('fill', p.x, p.y, 2) end
end

local function drawHUD()
    lg.setColor(1,1,1)
    if player then
        lg.print("Score: "..tostring(player.score), 12, 12)
        lg.print("HP: "..tostring(player.hp).."/"..tostring(player.maxhp), 12, 32)
        lg.printf(string.format("Level %d  XP:%d", player.level, player.xp), 12, 52, 400)
    end

    table.sort(entities, function(a,b) return a.score > b.score end)
    lg.printf("Top:", lg.getWidth()-180, 12, 170, 'left')
    for i=1,math.min(5,#entities) do
        local e = entities[i]; lg.printf(string.format("%d. %s (%d)", i, e.name, e.score), lg.getWidth()-180, 12+16*i, 170)
    end

    -- draw touch buttons
    ui.shootButton.x = lg.getWidth() - 90; ui.shootButton.y = lg.getHeight() - 90; ui.shootButton.r = 48
    ui.dashButton.x = lg.getWidth() - 90; ui.dashButton.y = lg.getHeight() - 170; ui.dashButton.r = 34

    -- shoot button (image or circle)
    if gfx.ui_fire then
        lg.setColor(1,1,1, ui.shootButton.pressed and 0.95 or 0.7)
        lg.draw(gfx.ui_fire, ui.shootButton.x, ui.shootButton.y, 0, 1, 1, gfx.ui_fire:getWidth()/2, gfx.ui_fire:getHeight()/2)
    else
        if ui.shootButton.pressed then lg.setColor(1,0.6,0.1,0.9) else lg.setColor(1,0.6,0.1,0.6) end
        lg.circle('fill', ui.shootButton.x, ui.shootButton.y, ui.shootButton.r)
        lg.setColor(1,1,1); lg.printf("FIRE", ui.shootButton.x - 24, ui.shootButton.y - 8, 48, 'center')
    end

    -- dash button
    if gfx.ui_dash then
        lg.setColor(1,1,1, ui.dashButton.pressed and 0.95 or 0.7)
        lg.draw(gfx.ui_dash, ui.dashButton.x, ui.dashButton.y, 0, 1, 1, gfx.ui_dash:getWidth()/2, gfx.ui_dash:getHeight()/2)
    else
        if ui.dashButton.pressed then lg.setColor(0.5,0.8,1,0.9) else lg.setColor(0.5,0.8,1,0.6) end
        lg.circle('fill', ui.dashButton.x, ui.dashButton.y, ui.dashButton.r)
        lg.setColor(0,0,0); lg.printf("DASH", ui.dashButton.x - 28, ui.dashButton.y - 8, 56, 'center')
    end

    -- kill feed
    for i,v in ipairs(ui.killFeed) do
        lg.setColor(1,1,1, 0.9 - (i-1)*0.12); lg.print(v.text, 12, 80 + (i-1)*18)
    end
end

-- Upgrade UI
local function drawUpgradeScreen()
    lg.clear(0.04,0.04,0.06,1)
    lg.setColor(1,1,1)
    lg.printf("Choose your upgrade", 0, 80, lg.getWidth(), 'center')
    if not player or not player.pendingUpgrade then return end
    local a = player.pendingUpgrade[1]
    local b = player.pendingUpgrade[2]
    local leftX, rightX = lg.getWidth()/2 - 220, lg.getWidth()/2 + 20
    local y = 180
    -- left option
    lg.setColor(0.12,0.12,0.16,0.9)
    lg.rectangle('fill', leftX, y, 200, 200, 8,8)
    lg.setColor(1,1,1)
    lg.printf("[1] "..a, leftX, y+12, 200, 'center')
    lg.printf("(Current: "..tostring(player.upgrades[a])..")", leftX, y+160, 200, 'center')
    -- right option
    lg.setColor(0.12,0.12,0.16,0.9)
    lg.rectangle('fill', rightX, y, 200, 200, 8,8)
    lg.setColor(1,1,1)
    lg.printf("[2] "..b, rightX, y+12, 200, 'center')
    lg.printf("(Current: "..tostring(player.upgrades[b])..")", rightX, y+160, 200, 'center')
    lg.setColor(0.8,0.8,0.8)
    lg.printf("Press 1 or 2 to pick. Space/Enter to confirm if using gamepad.", 0, lg.getHeight()-60, lg.getWidth(), 'center')
end

-- Touch state
local touchState = { active = false, id = nil, startx = 0, starty = 0, curx = 0, cury = 0 }

-- Self-test - runs simple simulation to verify core flows (non-invasive)
local function runSelfTest()
    print("[selftest] starting quick checks...")
    initGame(4)
    -- simulate a few steps
    for i=1,50 do
        -- move bots toward center
        for _,e in ipairs(entities) do
            if not e.isHuman and not e.dead then
                e.angle = math.atan2(WORLD.h/2 - e.y, WORLD.w/2 - e.x)
                if e.cooldown <= 0 then shootBullet(e) end
                e.cooldown = math.max(0, e.cooldown - 0.016)
            end
        end
        updateBullets(0.016)
    end
    print("[selftest] bullets updated; bullets count="..tostring(#bullets))
    print("[selftest] PASS (quick smoke). Run the game to fully validate visuals and controls.")
end

-- Life-cycle
function love.load()
    lg.setDefaultFilter('nearest','nearest')
    uiFont = lg.newFont(14); titleFont = lg.newFont(36); lg.setFont(uiFont)
    loadSettings(); loadSounds(); loadGraphics(); initGame()
    if DEBUG_SELFTEST then runSelfTest() end
end

function love.update(dt)
-- Dead-state guard: handle automatic return to menu while dead
if state == 'dead' then
    deathTimer = deathTimer + dt
    if deathTimer >= DEATH_RETURN_DELAY then
        deathTimer = 0
        state = 'menu'
        bullets = {}
        particles = {}
        entities = {}
        player = nil
    end
    return
end

    if state == 'playing' then
        timeElapsed = timeElapsed + dt

        -- decrement timers
        for _,e in ipairs(entities) do
            if e.invulTimer and e.invulTimer > 0 then e.invulTimer = e.invulTimer - dt; if e.invulTimer < 0 then e.invulTimer = 0 end end
            if e.isDashing then e.dashTimer = e.dashTimer - dt; if e.dashTimer <= 0 then e.isDashing = false end end
        end

        -- player movement (keyboard)
        local moveX, moveY = 0,0
        if love.keyboard.isDown('w','up') then moveY = moveY - 1 end
        if love.keyboard.isDown('s','down') then moveY = moveY + 1 end
        if love.keyboard.isDown('a','left') then moveX = moveX - 1 end
        if love.keyboard.isDown('d','right') then moveX = moveX + 1 end
        local len = math.sqrt(moveX*moveX + moveY*moveY)
        if len > 0 then moveX,moveY = moveX/len, moveY/len end
        local speed = player.isDashing and DASH_SPEED or PLAYER_SPEED
        player.x = clamp(player.x + moveX * speed * dt, 20, WORLD.w-20)
        player.y = clamp(player.y + moveY * speed * dt, 20, WORLD.h-20)

        -- mouse aim
        local mx,my = love.mouse.getPosition()
        player.angle = math.atan2((my + camera.y) - player.y, (mx + camera.x) - player.x)

        -- shooting (keyboard/mouse)
        player.cooldown = math.max(0, player.cooldown - dt)
        if love.mouse.isDown(1) and player.cooldown <= 0 and player.invulTimer <= 0 then shootBullet(player) end

        -- touch joystick movement
        if touchState.active then
            local dx = (touchState.curx - joystickSettings.x)
            local dy = (touchState.cury - joystickSettings.y)
            local dlen = math.sqrt(dx*dx + dy*dy)
            if dlen > 0 then
                player.x = clamp(player.x + (dx/dlen) * PLAYER_SPEED * dt, 20, WORLD.w-20)
                player.y = clamp(player.y + (dy/dlen) * PLAYER_SPEED * dt, 20, WORLD.h-20)
                player.angle = math.atan2((touchState.cury + camera.y) - player.y, (touchState.curx + camera.x) - player.x)
            end
        end

        -- shoot button held
        if ui.shootButton.pressed and player.cooldown <= 0 and player.invulTimer <= 0 then shootBullet(player) end

        -- dash button
        if ui.dashButton.pressed and not player.isDashing then player.isDashing = true; player.dashTimer = DASH_TIME; ui.dashButton.pressed = false end

        -- bots
        for _,e in ipairs(entities) do if not e.isHuman then updateBot(e, dt) end end

        -- bullets
        updateBullets(dt)

        -- particles
        for i=#particles,1,-1 do
            local p = particles[i]
            p.x = p.x + p.vx * dt
            p.y = p.y + p.vy * dt
            p.life = p.life - dt
            if p.life <= 0 then table.remove(particles,i) end
        end

        -- respawn
        for i,e in ipairs(entities) do
            if e.dead and e.respawnTimer then
                e.respawnTimer = e.respawnTimer - dt
                if e.respawnTimer <= 0 then
                    local oldscore = e.score
                    local isHuman = e.isHuman
                    local rx,ry = findSafeRespawn()
                    local newE = makeEntity(isHuman)
                    newE.score = oldscore
                    newE.x = rx; newE.y = ry
                    newE.invulTimer = RESPAWN_INVUL
                    if telemetry.enabled and telemetry.current and telemetry.current.perEntity and telemetry.current.perEntity[newE.name] then
                        telemetry.current.perEntity[newE.name].respawns = (telemetry.current.perEntity[newE.name].respawns or 0) + 1
                    end
                    if isHuman then player = newE end
                    for k=1,#entities do if entities[k].id == e.id then entities[k] = newE; break end end
                end
            end
        end

        updateCamera(dt)

        -- update kill feed timers
        for i=#ui.killFeed,1,-1 do ui.killFeed[i].timer = ui.killFeed[i].timer - dt; if ui.killFeed[i].timer <= 0 then table.remove(ui.killFeed, i) end end
    end
end

function love.draw()
    if state == 'menu' then
        lg.clear(0.04,0.04,0.06)
        lg.setFont(titleFont)
        lg.setColor(1,0.9,0.85)
        lg.printf("witch.io", 0, 80, lg.getWidth(), 'center')
        lg.setFont(uiFont)
        lg.setColor(0.9,0.9,0.95)
        lg.printf("Play (P)    Settings (S)    Quit (Esc)", 0, 170, lg.getWidth(), 'center')
        lg.printf("High Score: "..tostring(highscore), 0, 220, lg.getWidth(), 'center')
        lg.setColor(0.8,0.8,0.8)
        lg.printf("Tip: Use mouse or touch to aim. Fire button on-screen for mobile.", 0, lg.getHeight()-60, lg.getWidth(), 'center')
    elseif state == 'settings' then
        lg.clear(0.06,0.06,0.12)
        lg.setColor(1,1,1)
        lg.printf("Settings - Drag joystick to reposition; + / - to resize; S to save", 10, 10)
        lg.setColor(0.2,0.2,0.2,0.6); lg.circle('fill', joystickSettings.x, joystickSettings.y, joystickSettings.size)
    elseif state == 'upgrade' then
        drawUpgradeScreen()
    elseif state == 'dead' then
    -- draw world frozen underneath and HUD
    lg.push(); lg.translate(-camera.x, -camera.y); drawWorld(); lg.pop(); drawHUD()
    -- dark overlay
    lg.setColor(0,0,0,0.85); lg.rectangle('fill', 0, 0, lg.getWidth(), lg.getHeight())
    lg.setColor(1,1,1,1)
    local scoreText = 'Score: ' .. (player and tostring(player.score) or '0')
    local highText = 'High Score: ' .. tostring(highscore or 0)
    lg.printf('You Died', 0, lg.getHeight()/2 - 40, lg.getWidth(), 'center')
    lg.printf(scoreText, 0, lg.getHeight()/2 - 10, lg.getWidth(), 'center')
    lg.printf(highText, 0, lg.getHeight()/2 + 18, lg.getWidth(), 'center')
    lg.printf('Press any key or click/tap to return to menu', 0, lg.getHeight()/2 + 56, lg.getWidth(), 'center')
else
        lg.push(); lg.translate(-camera.x, -camera.y); drawWorld(); lg.pop(); drawHUD()
    end
end

function love.keypressed(key)
    if state == 'menu' then
        if key == 'p' then state = 'playing'; initGame() end
        if key == 's' then state = 'settings' end
        if key == 'f9' then telemetry.enabled = true; state = 'playing'; initGame() end
        if key == 'escape' then love.event.quit() end
    elseif state == 'playing' then
        if key == 'space' then player.isDashing = true; player.dashTimer = DASH_TIME end
        if key == 'escape' then state = 'menu' end
    elseif state == 'settings' then
        if key == 's' then saveSettings(); state = 'menu' end
        if key == 'plus' or key=='=' then joystickSettings.size = joystickSettings.size + 6 end
        if key == 'minus' or key == '_' then joystickSettings.size = math.max(40, joystickSettings.size - 6) end
    elseif state == 'dead' then
        if key == 'p' then state = 'playing'; initGame() end
        if key == 'm' then state = 'menu' end
    elseif state == 'upgrade' and player and player.pendingUpgrade then
        if key == '1' or key == '2' then
            local pick = player.pendingUpgrade[tonumber(key)]
            player.upgrades[pick] = clamp(player.upgrades[pick] + 1, 0, UPGRADE_CAP)
            if pick == 'maxHP' then player.maxhp = player.maxhp + 1; player.hp = player.hp + 1 end
            player.pendingUpgrade = nil
            state = 'playing'
            if sounds.levelup and sounds.levelup.play then sounds.levelup:play() end
        end
    end
end

-- Touch / mouse
function love.touchpressed(id, x, y, dx, dy, pressure)
    touchState.active = true; touchState.id = id
    touchState.startx = x * lg.getWidth(); touchState.starty = y * lg.getHeight()
    touchState.curx = touchState.startx; touchState.cury = touchState.starty
    -- check shoot button
    local sx = lg.getWidth() - 90; local sy = lg.getHeight() - 90; local sr = 48
    if dist(touchState.curx, touchState.cury, sx, sy) <= sr then ui.shootButton.pressed = true end
    -- check dash
    local dx2 = lg.getWidth() - 90; local dy2 = lg.getHeight() - 170; local dr2 = 34
    if dist(touchState.curx, touchState.cury, dx2, dy2) <= dr2 then ui.dashButton.pressed = true end
end

function love.touchmoved(id, x, y, dx, dy, pressure)
    if touchState.active and touchState.id == id then touchState.curx = x * lg.getWidth(); touchState.cury = y * lg.getHeight() end
end

function love.touchreleased(id, x, y, dx, dy, pressure)
    if touchState.id == id then touchState.active = false; touchState.id = nil; ui.shootButton.pressed = false; ui.dashButton.pressed = false end
end

function love.mousepressed(x,y,b)
    if state == 'settings' and b == 1 and dist(x,y, joystickSettings.x, joystickSettings.y) <= joystickSettings.size then joystickSettings.x = x; joystickSettings.y = y end
    -- mouse click on shoot/dash for desktop
    if state == 'playing' and b == 1 then
        local sx = lg.getWidth() - 90; local sy = lg.getHeight() - 90; local sr = 48
        if dist(x,y,sx,sy) <= sr then ui.shootButton.pressed = true; ui.shootButton.desktopClick = true; shootBullet(player) end
        local dx2 = lg.getWidth() - 90; local dy2 = lg.getHeight() - 170; local dr2 = 34
        if dist(x,y,dx2,dy2) <= dr2 then ui.dashButton.pressed = true; ui.dashButton.desktopClick = true; player.isDashing = true; player.dashTimer = DASH_TIME end
    elseif state == 'menu' then
        -- allow click to start
        if b == 1 then state = 'playing'; initGame() end
    end
end

function love.mousereleased(x,y,b)
    if ui.shootButton and ui.shootButton.desktopClick then ui.shootButton.pressed = false; ui.shootButton.desktopClick = false end
    if ui.dashButton and ui.dashButton.desktopClick then ui.dashButton.pressed = false; ui.dashButton.desktopClick = false end
end

function love.quit()
    if telemetry.enabled and telemetry.current then telemetry.current['end'] = os.time(); table.insert(telemetry.runs, telemetry.current) end
    saveSettings()
end

-- End of main.lua

function enterDeadState()
    print('[STATE] Playing → Dead')
    deathTimer = 0
    gameState = 'Dead'
end
