witch.io - Love2D project (placeholder assets included)
------------------------------------------------------
How to run:
  1. Install Love2D (https://love2d.org).
  2. Place this project folder in a convenient location.
  3. Run `love .` from the project folder, or drag the folder onto the Love2D executable.

Included files:
  - conf.lua
  - main.lua
  - assets/* (small placeholder PNGs)
  - tuning.json (recommended balance tweaks)

Notes:
  - If you enable DEBUG_SELFTEST in main.lua (set to true), the game will run a quick internal self-test on load.
  - I cannot run Love2D in this environment. I performed static checks and added placeholder assets and a zip package you can download.
