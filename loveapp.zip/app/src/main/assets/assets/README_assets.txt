Placeholder assets for witch.io project

Images:
- witch_player.png
- witch_bot.png
- bullet.png
- bg_tile.png
- ui_fire.png
- ui_dash.png

Sounds:
- shoot.wav
- hit.wav
- levelup.wav
- death.wav
- ui.wav
- music.wav

These are simple placeholder assets created automatically. Replace with your own art and audio by overwriting files in the assets/ folder.
